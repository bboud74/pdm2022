let x = 0;
let y = 0;
let z = 0;
let x1;
let x2;

function setup() {
  createCanvas(800, 700);
  background(250);
}

function draw() {
  noStroke();
  //red
  fill(255,0,0);
  rect(5,5,20,20);
  //orange
  fill(255,165,0);
  rect(5,27,20,20);
  //yellow
  fill(255,255,0);
  rect(5,49,20,20);
  //green
  fill(0,255,0);
  rect(5,71,20,20);
  //cyan
  fill(0,255,255);
  rect(5,93,20,20);
  //blue
  fill(0,0,255);
  rect(5,115,20,20);
  //magenta
  fill(255,0,255);
  rect(5,137,20,20);
  //brown
  fill(155,75,0);
  rect(5,159,20,20);
  //white
  fill(255,255,255);
  rect(5,181,20,20);
  //black
  fill(0,0,0);
  rect(5,203,20,20);

  if(mouseIsPressed){
    if(collide(5,5)){
      x = 255;
      y = 0;
      z = 0;
    }
    if(collide(5,27)){
      x = 255;
      y = 165;
      z = 0;
    }
    if(collide(5,49)){
      x = 255;
      y = 255;
      z = 0;
    }
    if(collide(5,71)){
      x = 0;
      y = 255;
      z = 0;
    }
    if(collide(5,93)){
      x = 0;
      y = 255;
      z = 255;
    }
    if(collide(5,115)){
      x = 0;
      y = 0;
      z = 255;
    }
    if(collide(5,137)){
      x = 255;
      y = 0;
      z = 255;
    }
    if(collide(5,159)){
      x = 155;
      y = 75;
      z = 0;
    }
    if(collide(5,181)){
      x = 255;
      y = 255;
      z = 255;
    }
    if(collide(5,203)){
      x = 0;
      y = 0;
      z = 0;
    }
    else{
      strokeWeight(10);
      stroke(x,y,z);
      line(pmouseX,pmouseY,mouseX,mouseY);
    }
  }

}

function collide(x1,x2){
  if(mouseX >= x1 && mouseX <= (x1 +20) && mouseY >= x2 && mouseY <= (x2 +20)){
    return true
  }
  
  return false;
}

